//create jar, name jar, place string in jar
var firstName = "Marco";

//alert is method (built in function in JS)
// alert("Hello" + firstName);

//modern JS
// alert(`Hello ${firstName}`);

// console.log("Hello " + firstName);

console.log("javascript linked up");